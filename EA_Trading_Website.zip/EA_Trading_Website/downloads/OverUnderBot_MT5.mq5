//+------------------------------------------------------------------+
//| OverUnderBot_MT5.mq5                                             |
//+------------------------------------------------------------------+
#property strict
#property version "1.00"

#include <Trade/Trade.mqh>
CTrade trade;

input double Lots=0.01;
input int EMAPeriod=20;
input int RSIPeriod=14;
input double NumberStep=1.0;
input double TPPoints=100.0;
input double SLPoints=100.0;
input int MaxConsecutiveLosses=3;
input int MaxSpreadPoints=80;
input long Magic=20260924;

int emaHandle=INVALID_HANDLE;
int rsiHandle=INVALID_HANDLE;
datetime lastBar=0;

double currentNumber=0;
int consecutiveLosses=0;
int totalTrades=0;
int wins=0;
int losses=0;

double PriceNormalize(double p)
{
   return NormalizeDouble(p,(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS));
}

bool HasPosition()
{
   if(!PositionSelect(_Symbol)) return false;
   return (long)PositionGetInteger(POSITION_MAGIC)==Magic;
}

double BufferValue(int handle,int shift)
{
   double a[];
   ArraySetAsSeries(a,true);
   if(CopyBuffer(handle,0,shift,1,a)!=1) return EMPTY_VALUE;
   return a[0];
}

bool NewBar()
{
   datetime t=iTime(_Symbol,PERIOD_CURRENT,0);
   if(t==0 || t==lastBar) return false;
   lastBar=t;
   return true;
}

bool SpreadOK()
{
   double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   if(ask<=0 || bid<=0) return false;
   return ((ask-bid)/_Point)<=MaxSpreadPoints;
}

void Panel()
{
   string mode="WAIT";
   if(HasPosition())
   {
      long type=PositionGetInteger(POSITION_TYPE);
      mode=(type==POSITION_TYPE_BUY)?"OVER":"UNDER";
   }
   if(consecutiveLosses>=MaxConsecutiveLosses) mode="STOPPED";

   Comment(
      "OVER / UNDER MT5 BOT\n",
      "Symbol: ",_Symbol,"\n",
      "Mode: ",mode,"\n",
      "Number: ",DoubleToString(currentNumber,2),"\n",
      "TOTAL: ",totalTrades,"  WIN: ",wins,"  LOSS: ",losses,"\n",
      "CONSEC LOSS: ",consecutiveLosses,"\n",
      "Lots: ",DoubleToString(Lots,2)
   );
}

int OnInit()
{
   if(Lots<=0 || NumberStep<=0 || TPPoints<=0 || SLPoints<=0)
      return INIT_PARAMETERS_INCORRECT;

   emaHandle=iMA(_Symbol,PERIOD_CURRENT,EMAPeriod,0,MODE_EMA,PRICE_CLOSE);
   rsiHandle=iRSI(_Symbol,PERIOD_CURRENT,RSIPeriod,PRICE_CLOSE);

   if(emaHandle==INVALID_HANDLE || rsiHandle==INVALID_HANDLE)
      return INIT_FAILED;

   trade.SetExpertMagicNumber(Magic);
   trade.SetDeviationInPoints(20);

   double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   if(bid>0)
      currentNumber=MathRound(bid/NumberStep)*NumberStep;

   Panel();
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   if(emaHandle!=INVALID_HANDLE) IndicatorRelease(emaHandle);
   if(rsiHandle!=INVALID_HANDLE) IndicatorRelease(rsiHandle);
   Comment("");
}

void OnTradeTransaction(
   const MqlTradeTransaction &trans,
   const MqlTradeRequest &request,
   const MqlTradeResult &result)
{
   if(trans.type!=TRADE_TRANSACTION_DEAL_ADD) return;
   if(trans.deal==0 || !HistoryDealSelect(trans.deal)) return;

   if((long)HistoryDealGetInteger(trans.deal,DEAL_MAGIC)!=Magic) return;

   long entry=(long)HistoryDealGetInteger(trans.deal,DEAL_ENTRY);
   if(entry!=DEAL_ENTRY_OUT && entry!=DEAL_ENTRY_OUT_BY) return;

   double profit=
      HistoryDealGetDouble(trans.deal,DEAL_PROFIT)+
      HistoryDealGetDouble(trans.deal,DEAL_SWAP)+
      HistoryDealGetDouble(trans.deal,DEAL_COMMISSION);

   if(profit>0)
   {
      wins++;
      consecutiveLosses=0;

      double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
      if(bid>0) currentNumber=MathRound(bid/NumberStep)*NumberStep;
   }
   else if(profit<0)
   {
      losses++;
      consecutiveLosses++;

      // LOSS -> next number
      currentNumber+=NumberStep;
   }

   Panel();
}

void OnTick()
{
   Panel();

   if(consecutiveLosses>=MaxConsecutiveLosses) return;
   if(HasPosition()) return;
   if(!NewBar()) return;
   if(!SpreadOK()) return;

   double ema=BufferValue(emaHandle,1);
   double rsi=BufferValue(rsiHandle,1);
   double close1=iClose(_Symbol,PERIOD_CURRENT,1);

   if(ema==EMPTY_VALUE || rsi==EMPTY_VALUE || close1<=0) return;

   bool over=(close1>ema && rsi>50);
   bool under=(close1<ema && rsi<50);

   double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);

   if(over)
   {
      currentNumber+=NumberStep;

      double sl=PriceNormalize(ask-SLPoints*_Point);
      double tp=PriceNormalize(ask+TPPoints*_Point);

      if(trade.Buy(Lots,_Symbol,0,sl,tp,"OVER"))
         totalTrades++;
   }
   else if(under)
   {
      currentNumber-=NumberStep;

      double sl=PriceNormalize(bid+SLPoints*_Point);
      double tp=PriceNormalize(bid-TPPoints*_Point);

      if(trade.Sell(Lots,_Symbol,0,sl,tp,"UNDER"))
         totalTrades++;
   }

   Panel();
}
//+------------------------------------------------------------------+
