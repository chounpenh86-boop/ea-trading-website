//+------------------------------------------------------------------+
//| SCALPING_MULTI_TRADE_V1.mq5                                     |
//| Multi-entry scalping EA: balance/risk + market strength          |
//+------------------------------------------------------------------+
#property strict
#property version "1.00"

#include <Trade/Trade.mqh>
CTrade trade;

input long   MagicNumber          = 26092501;
input double FixedLot             = 0.01;
input bool   UseRiskPercent       = true;
input double RiskPercent          = 0.50;

input int    MaxTrades            = 10;
input double MinFreeMarginPercent = 30.0;
input int    MinDistancePoints    = 30;
input int    MaxSpreadPoints      = 80;
input int    CooldownSeconds      = 10;

input ENUM_TIMEFRAMES SignalTF     = PERIOD_M1;
input int    FastEMA               = 9;
input int    SlowEMA               = 21;
input int    RSIPeriod             = 14;
input double BuyRSI                = 55.0;
input double SellRSI               = 45.0;
input int    ATRPeriod             = 14;
input double MinATRPoints          = 20.0;

input double SLPoints              = 100.0;
input double TPPoints              = 50.0;
input bool   UseTrailing            = true;
input double TrailStartPoints      = 25.0;
input double TrailDistancePoints   = 15.0;

input bool   ScaleByMarketStrength = true;
input int    WeakMaxTrades         = 2;
input int    NormalMaxTrades       = 5;
input int    StrongMaxTrades       = 10;
input double NormalEMAGapATR       = 0.10;
input double StrongEMAGapATR       = 0.25;

input bool AllowBuy                = true;
input bool AllowSell               = true;
input bool OneDirectionAtATime     = true;

int emaFastHandle=INVALID_HANDLE, emaSlowHandle=INVALID_HANDLE;
int rsiHandle=INVALID_HANDLE, atrHandle=INVALID_HANDLE;
datetime lastSignalBar=0, lastTradeTime=0;

double NormalizePrice(double p)
{
   return NormalizeDouble(p,(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS));
}

double NormalizeVolume(double v)
{
   double mn=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   double mx=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   double st=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   if(st<=0) st=mn;
   v=MathMax(mn,MathMin(mx,v));
   v=MathFloor(v/st)*st;
   return NormalizeDouble(v,2);
}

double Buf(int handle,int shift)
{
   double a[];
   ArraySetAsSeries(a,true);
   if(CopyBuffer(handle,0,shift,1,a)!=1) return EMPTY_VALUE;
   return a[0];
}

int CountPositions(int wanted=-1)
{
   int n=0;
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0 || !PositionSelectByTicket(ticket)) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if((long)PositionGetInteger(POSITION_MAGIC)!=MagicNumber) continue;

      long type=PositionGetInteger(POSITION_TYPE);
      if(wanted==-1 || type==wanted) n++;
   }
   return n;
}

bool HasOpposite(long wanted)
{
   long opposite=(wanted==POSITION_TYPE_BUY)?POSITION_TYPE_SELL:POSITION_TYPE_BUY;
   return CountPositions(opposite)>0;
}

double LastEntry(long wanted)
{
   double p=0;
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0 || !PositionSelectByTicket(ticket)) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if((long)PositionGetInteger(POSITION_MAGIC)!=MagicNumber) continue;
      if((long)PositionGetInteger(POSITION_TYPE)!=wanted) continue;

      double x=PositionGetDouble(POSITION_PRICE_OPEN);
      if(p==0) p=x;
      else if(wanted==POSITION_TYPE_BUY) p=MathMax(p,x);
      else p=MathMin(p,x);
   }
   return p;
}

double LotSize(double entry,double sl)
{
   if(!UseRiskPercent) return NormalizeVolume(FixedLot);

   double riskMoney=AccountInfoDouble(ACCOUNT_BALANCE)*RiskPercent/100.0;
   double tickSize=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   double tickValue=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_VALUE);

   if(riskMoney<=0 || tickSize<=0 || tickValue<=0)
      return NormalizeVolume(FixedLot);

   double lossPerLot=(MathAbs(entry-sl)/tickSize)*tickValue;
   if(lossPerLot<=0) return NormalizeVolume(FixedLot);

   return NormalizeVolume(riskMoney/lossPerLot);
}

bool SpreadOK()
{
   double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   if(ask<=0 || bid<=0) return false;
   return ((ask-bid)/_Point)<=MaxSpreadPoints;
}

bool MarginOK(ENUM_ORDER_TYPE type,double lot,double price)
{
   double equity=AccountInfoDouble(ACCOUNT_EQUITY);
   double free=AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   if(equity<=0 || free<=0) return false;
   if((free/equity)*100.0 < MinFreeMarginPercent) return false;

   double margin=0;
   if(!OrderCalcMargin(type,_Symbol,lot,price,margin)) return false;
   return free>margin;
}

int MarketStrength(double fast,double slow,double atr)
{
   if(atr<=0) return 0;
   double gap=MathAbs(fast-slow)/atr;
   if(gap>=StrongEMAGapATR) return 2;
   if(gap>=NormalEMAGapATR) return 1;
   return 0;
}

int AllowedTrades(int strength)
{
   if(!ScaleByMarketStrength) return MaxTrades;
   if(strength>=2) return MathMin(MaxTrades,StrongMaxTrades);
   if(strength==1) return MathMin(MaxTrades,NormalMaxTrades);
   return MathMin(MaxTrades,WeakMaxTrades);
}

bool NewBar()
{
   datetime t=iTime(_Symbol,SignalTF,0);
   if(t==0 || t==lastSignalBar) return false;
   lastSignalBar=t;
   return true;
}

void OpenBuy(int allowed)
{
   if(!AllowBuy || CountPositions(POSITION_TYPE_BUY)>=allowed) return;
   if(OneDirectionAtATime && HasOpposite(POSITION_TYPE_BUY)) return;
   if(TimeCurrent()-lastTradeTime<CooldownSeconds) return;

   double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   double sl=NormalizePrice(ask-SLPoints*_Point);
   double tp=NormalizePrice(ask+TPPoints*_Point);
   double lot=LotSize(ask,sl);
   double last=LastEntry(POSITION_TYPE_BUY);

   if(last>0 && MathAbs(ask-last)/_Point<MinDistancePoints) return;
   if(!MarginOK(ORDER_TYPE_BUY,lot,ask)) return;

   if(trade.Buy(lot,_Symbol,0,sl,tp,"SCALP BUY"))
   {
      if(trade.ResultRetcode()==TRADE_RETCODE_DONE ||
         trade.ResultRetcode()==TRADE_RETCODE_DONE_PARTIAL)
         lastTradeTime=TimeCurrent();
   }
}

void OpenSell(int allowed)
{
   if(!AllowSell || CountPositions(POSITION_TYPE_SELL)>=allowed) return;
   if(OneDirectionAtATime && HasOpposite(POSITION_TYPE_SELL)) return;
   if(TimeCurrent()-lastTradeTime<CooldownSeconds) return;

   double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   double sl=NormalizePrice(bid+SLPoints*_Point);
   double tp=NormalizePrice(bid-TPPoints*_Point);
   double lot=LotSize(bid,sl);
   double last=LastEntry(POSITION_TYPE_SELL);

   if(last>0 && MathAbs(bid-last)/_Point<MinDistancePoints) return;
   if(!MarginOK(ORDER_TYPE_SELL,lot,bid)) return;

   if(trade.Sell(lot,_Symbol,0,sl,tp,"SCALP SELL"))
   {
      if(trade.ResultRetcode()==TRADE_RETCODE_DONE ||
         trade.ResultRetcode()==TRADE_RETCODE_DONE_PARTIAL)
         lastTradeTime=TimeCurrent();
   }
}

void Trailing()
{
   if(!UseTrailing) return;

   double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);

   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0 || !PositionSelectByTicket(ticket)) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if((long)PositionGetInteger(POSITION_MAGIC)!=MagicNumber) continue;

      long type=PositionGetInteger(POSITION_TYPE);
      double open=PositionGetDouble(POSITION_PRICE_OPEN);
      double sl=PositionGetDouble(POSITION_SL);
      double tp=PositionGetDouble(POSITION_TP);

      if(type==POSITION_TYPE_BUY)
      {
         if((bid-open)/_Point>=TrailStartPoints)
         {
            double ns=NormalizePrice(bid-TrailDistancePoints*_Point);
            if(sl==0 || ns>sl) trade.PositionModify(ticket,ns,tp);
         }
      }
      else
      {
         if((open-ask)/_Point>=TrailStartPoints)
         {
            double ns=NormalizePrice(ask+TrailDistancePoints*_Point);
            if(sl==0 || ns<sl) trade.PositionModify(ticket,ns,tp);
         }
      }
   }
}

void Panel(int strength,int allowed)
{
   string m=(strength>=2)?"STRONG":(strength==1?"NORMAL":"WEAK");
   int buys=CountPositions(POSITION_TYPE_BUY);
   int sells=CountPositions(POSITION_TYPE_SELL);

   Comment(
      "SCALPING MULTI TRADE V1\n",
      "Market: ",m,"\n",
      "Trades: ",buys+sells," / ",allowed,"\n",
      "BUY: ",buys," | SELL: ",sells,"\n",
      "Balance: ",DoubleToString(AccountInfoDouble(ACCOUNT_BALANCE),2),"\n",
      "Equity: ",DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY),2),"\n",
      "Free Margin: ",DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_FREE),2),"\n",
      "Risk: ",DoubleToString(RiskPercent,2),"%\n",
      "TP: ",DoubleToString(TPPoints,0),
      " | SL: ",DoubleToString(SLPoints,0)
   );
}

int OnInit()
{
   if(FastEMA>=SlowEMA || MaxTrades<=0 || SLPoints<=0 || TPPoints<=0)
      return INIT_PARAMETERS_INCORRECT;

   emaFastHandle=iMA(_Symbol,SignalTF,FastEMA,0,MODE_EMA,PRICE_CLOSE);
   emaSlowHandle=iMA(_Symbol,SignalTF,SlowEMA,0,MODE_EMA,PRICE_CLOSE);
   rsiHandle=iRSI(_Symbol,SignalTF,RSIPeriod,PRICE_CLOSE);
   atrHandle=iATR(_Symbol,SignalTF,ATRPeriod);

   if(emaFastHandle==INVALID_HANDLE || emaSlowHandle==INVALID_HANDLE ||
      rsiHandle==INVALID_HANDLE || atrHandle==INVALID_HANDLE)
      return INIT_FAILED;

   trade.SetExpertMagicNumber(MagicNumber);
   trade.SetDeviationInPoints(20);
   trade.SetTypeFillingBySymbol(_Symbol);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   if(emaFastHandle!=INVALID_HANDLE) IndicatorRelease(emaFastHandle);
   if(emaSlowHandle!=INVALID_HANDLE) IndicatorRelease(emaSlowHandle);
   if(rsiHandle!=INVALID_HANDLE) IndicatorRelease(rsiHandle);
   if(atrHandle!=INVALID_HANDLE) IndicatorRelease(atrHandle);
   Comment("");
}

void OnTick()
{
   Trailing();

   double fast=Buf(emaFastHandle,1);
   double slow=Buf(emaSlowHandle,1);
   double rsi=Buf(rsiHandle,1);
   double atr=Buf(atrHandle,1);

   if(fast==EMPTY_VALUE || slow==EMPTY_VALUE ||
      rsi==EMPTY_VALUE || atr==EMPTY_VALUE) return;

   int strength=MarketStrength(fast,slow,atr);
   int allowed=AllowedTrades(strength);
   Panel(strength,allowed);

   if(!NewBar() || !SpreadOK()) return;
   if((atr/_Point)<MinATRPoints) return;

   bool buy=(fast>slow && rsi>=BuyRSI);
   bool sell=(fast<slow && rsi<=SellRSI);

   if(buy) OpenBuy(allowed);
   if(sell) OpenSell(allowed);
}
//+------------------------------------------------------------------+
