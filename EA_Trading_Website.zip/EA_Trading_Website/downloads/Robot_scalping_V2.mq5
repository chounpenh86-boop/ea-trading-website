//+------------------------------------------------------------------+
//| Robot scalping V2 - MT5 Expert Advisor                          |
//+------------------------------------------------------------------+
#property strict
#property version "2.00"

#include <Trade/Trade.mqh>
CTrade trade;

input string RobotName="Robot scalping";
input double LotSize=0.01;
input ulong MagicNumber=20260922;
input ENUM_TIMEFRAMES TradeTimeframe=PERIOD_M1;

input int FastEMA=9;
input int SlowEMA=21;
input int RSIPeriod=14;
input double BuyRSI=52.0;
input double SellRSI=48.0;

input int StopLossPoints=300;
input int TakeProfitPoints=450;

input bool UseBreakEven=true;
input int BreakEvenStart=150;
input int BreakEvenLock=20;

input bool UseTrailing=true;
input int TrailingStart=220;
input int TrailingDistance=100;

input int MaxSpreadPoints=80;
input int MaxTradesPerDay=20;

int emaFastHandle,emaSlowHandle,rsiHandle;
datetime LastBar=0;
int TradesToday=0,CurrentDay=-1;

int OnInit()
{
   trade.SetExpertMagicNumber(MagicNumber);
   trade.SetDeviationInPoints(30);
   trade.SetTypeFillingBySymbol(_Symbol);

   emaFastHandle=iMA(_Symbol,TradeTimeframe,FastEMA,0,MODE_EMA,PRICE_CLOSE);
   emaSlowHandle=iMA(_Symbol,TradeTimeframe,SlowEMA,0,MODE_EMA,PRICE_CLOSE);
   rsiHandle=iRSI(_Symbol,TradeTimeframe,RSIPeriod,PRICE_CLOSE);

   if(emaFastHandle==INVALID_HANDLE || emaSlowHandle==INVALID_HANDLE || rsiHandle==INVALID_HANDLE)
      return INIT_FAILED;

   Print(RobotName," V2 started on ",_Symbol);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   IndicatorRelease(emaFastHandle);
   IndicatorRelease(emaSlowHandle);
   IndicatorRelease(rsiHandle);
}

bool IsNewBar()
{
   datetime t=iTime(_Symbol,TradeTimeframe,0);
   if(t!=LastBar)
   {
      LastBar=t;
      return true;
   }
   return false;
}

void CheckNewDay()
{
   MqlDateTime tm;
   TimeToStruct(TimeCurrent(),tm);
   if(CurrentDay!=tm.day)
   {
      CurrentDay=tm.day;
      TradesToday=0;
   }
}

bool SpreadOK()
{
   double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   return _Point>0 && ((ask-bid)/_Point)<=MaxSpreadPoints;
}

bool HasRobotPosition()
{
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0 || !PositionSelectByTicket(ticket)) continue;

      if(PositionGetString(POSITION_SYMBOL)==_Symbol &&
         (ulong)PositionGetInteger(POSITION_MAGIC)==MagicNumber)
         return true;
   }
   return false;
}

int GetSignal()
{
   double fast[3],slow[3],rsi[3];
   ArraySetAsSeries(fast,true);
   ArraySetAsSeries(slow,true);
   ArraySetAsSeries(rsi,true);

   if(CopyBuffer(emaFastHandle,0,0,3,fast)<3) return 0;
   if(CopyBuffer(emaSlowHandle,0,0,3,slow)<3) return 0;
   if(CopyBuffer(rsiHandle,0,0,3,rsi)<3) return 0;

   double open1=iOpen(_Symbol,TradeTimeframe,1);
   double close1=iClose(_Symbol,TradeTimeframe,1);
   double high2=iHigh(_Symbol,TradeTimeframe,2);
   double low2=iLow(_Symbol,TradeTimeframe,2);

   bool buy=fast[1]>slow[1] && rsi[1]>=BuyRSI && close1>open1 && close1>high2;
   bool sell=fast[1]<slow[1] && rsi[1]<=SellRSI && close1<open1 && close1<low2;

   if(buy) return 1;
   if(sell) return -1;
   return 0;
}

void OpenBuy()
{
   double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   double sl=NormalizeDouble(ask-StopLossPoints*_Point,_Digits);
   double tp=NormalizeDouble(ask+TakeProfitPoints*_Point,_Digits);

   if(trade.Buy(LotSize,_Symbol,0,sl,tp,RobotName+" BUY"))
      TradesToday++;
   else
      Print("BUY failed: ",trade.ResultRetcodeDescription());
}

void OpenSell()
{
   double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   double sl=NormalizeDouble(bid+StopLossPoints*_Point,_Digits);
   double tp=NormalizeDouble(bid-TakeProfitPoints*_Point,_Digits);

   if(trade.Sell(LotSize,_Symbol,0,sl,tp,RobotName+" SELL"))
      TradesToday++;
   else
      Print("SELL failed: ",trade.ResultRetcodeDescription());
}

void ManagePositions()
{
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0 || !PositionSelectByTicket(ticket)) continue;

      if(PositionGetString(POSITION_SYMBOL)!=_Symbol ||
         (ulong)PositionGetInteger(POSITION_MAGIC)!=MagicNumber)
         continue;

      ENUM_POSITION_TYPE type=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      double openPrice=PositionGetDouble(POSITION_PRICE_OPEN);
      double currentSL=PositionGetDouble(POSITION_SL);
      double currentTP=PositionGetDouble(POSITION_TP);
      double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
      double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);

      if(type==POSITION_TYPE_BUY)
      {
         double profitPoints=(bid-openPrice)/_Point;

         if(UseBreakEven && profitPoints>=BreakEvenStart)
         {
            double newSL=NormalizeDouble(openPrice+BreakEvenLock*_Point,_Digits);
            if(currentSL==0 || newSL>currentSL)
               trade.PositionModify(ticket,newSL,currentTP);
         }

         if(UseTrailing && profitPoints>=TrailingStart)
         {
            double newSL=NormalizeDouble(bid-TrailingDistance*_Point,_Digits);
            if(currentSL==0 || newSL>currentSL)
               trade.PositionModify(ticket,newSL,currentTP);
         }
      }

      if(type==POSITION_TYPE_SELL)
      {
         double profitPoints=(openPrice-ask)/_Point;

         if(UseBreakEven && profitPoints>=BreakEvenStart)
         {
            double newSL=NormalizeDouble(openPrice-BreakEvenLock*_Point,_Digits);
            if(currentSL==0 || newSL<currentSL)
               trade.PositionModify(ticket,newSL,currentTP);
         }

         if(UseTrailing && profitPoints>=TrailingStart)
         {
            double newSL=NormalizeDouble(ask+TrailingDistance*_Point,_Digits);
            if(currentSL==0 || newSL<currentSL)
               trade.PositionModify(ticket,newSL,currentTP);
         }
      }
   }
}

void OnTick()
{
   CheckNewDay();
   ManagePositions();

   if(!IsNewBar()) return;
   if(!SpreadOK()) return;
   if(TradesToday>=MaxTradesPerDay) return;
   if(HasRobotPosition()) return;

   int signal=GetSignal();
   if(signal==1) OpenBuy();
   if(signal==-1) OpenSell();
}
//+------------------------------------------------------------------+
