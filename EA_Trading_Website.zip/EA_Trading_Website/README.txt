EA Trading Hub website

Files:
- index.html : website
- downloads/ : MT5 EA files

Publish with GitHub Pages:
1. Create a GitHub repository.
2. Upload index.html and the downloads folder.
3. Open Settings -> Pages.
4. Select Deploy from a branch, choose main and /root, then Save.
5. GitHub will publish the site at your Pages URL.

Important: This version uses direct downloadable .mq5 source files. If you plan to sell the EA, consider using a proper licensing/distribution system rather than publicly exposing source code.
